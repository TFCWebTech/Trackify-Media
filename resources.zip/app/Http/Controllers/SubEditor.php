<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubEditor extends Controller
{
    //
    public function index(){
        return view('sub_editor');
    }
}
