<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Sector extends Controller
{
    //
    public function index(){
        return view('category/sector');
    }

    // public function addSector(Request $request){
    //     $validation =[
    //         ''
    //     ];
    // }

    }
