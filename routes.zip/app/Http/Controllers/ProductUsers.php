<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductUsers extends Controller
{
    //
    public function index(){
        return view('category/product_user');
    }
}
