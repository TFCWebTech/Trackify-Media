<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Our Trackify Media Team</title>
</head>
<body style='border-top: 10px solid #3fa3df ;text-align: center; color:#000 !important;'>
    <div style='text-align: center;padding: 10px; background-color:white;'>
        <img src='https://pressbro.com/News/assets/img/mediaLogo.png' style='width: 20%;vertical-align:middle'>
    </div>
    <div style='background-color: #fff; color:#000 !important; padding: 0% 10%; text-align: center;'>
        <h3 align='center'> <span style="font-size:18px;">Generate Password</span> <br>
        Hello,</h3>
        <p style='color: #757272; text-align:center:'>To generate your password please click on the button below.
            <a href="<?php echo e(route('user.ganeratePassword', [$clientId, $token])); ?>" style="text-decoration: none;  color: #fff; ">Generate Password</a>
        </p>
    </div>
    <p>Thank you for joining our Team.</p>
    <p>Thank you</p>
</body>
</html><?php /**PATH C:\laravel\Trackify-Media\resources\views/emails/user_password_mail.blade.php ENDPATH**/ ?>