<?php echo $__env->make('common\header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.min.js"></script>
<style>
.lightbox {
    display: none;
    position: fixed;
    z-index: 999;
    width: 100%;
    height: 100%;
    text-align: center;
    top: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.8);
}

.lightbox img {
    max-width: 90%;
    max-height: 80%;
    margin-top: 2%;
}

.lightbox:target {
    /* Show the lightbox */
    display: block;
}
.close {
    position: absolute;
    top: 20px;
    right: 20px;
    font-size: 3em;
    color: #fff;
    text-decoration: none;
}

.thumbnail {
    max-width: 180px;
}

.thumbnail-wrapper {
    display: flex;
    align-items: left;
    justify-content: center;
}
body {
    background-color: #fbffdd;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}
        /* CSS to temporarily hide elements */
        /* .no-pdf {
            display: none;
        } */
        /* .show_in_pdf {
            display: none;
        } */
#generatePDF {
            background-color: #0080FF ;
            color: #ffffff;
            border-color: #0080FF ;
            border-radius: 5px;
        }
        #wrapper #content-wrapper #content-2 {
    flex: 1 0 auto !important;
}
       
</style>
  <!-- Include Font Awesome for icons -->
  <div class="container">
    <div class="row no-pdf">
        <div class="col-md-12 text-right mb-2">
            <button id="generatePDF"><i class="fa fa-download"></i></button>
        </div>
    </div>
    <div class="card no-pdf">
    <?php if(!empty($newsDetail)): ?>
    <div class="row p-2">
        <div class="col-md-12 pt-1"> 
            <h5 style="color:blue;">
                <a href="<?php echo e($newsDetail['website_url']); ?>"><?php echo e($newsDetail['head_line']); ?></a>
            </h5>
            <label for="">Summary</label> <br>
            <p><?php echo e($newsDetail['summary']); ?></p>
            <p>
                Publication: <span style="color:blue;"><?php echo e($newsDetail['media_outlet']['MediaOutlet']); ?></span>, 
                Journalist / Agency: <span style="color:blue;"><?php echo e($newsDetail['journalist']['Journalist'] ?? $newsDetail['agency']['Agency']); ?></span>, 
                Edition: <span style="color:blue;"><?php echo e($newsDetail['edition']['Edition']); ?></span>, 
                Supplement: <span style="color:blue;"><?php echo e($newsDetail['supplement']['Supplement']); ?></span>
                <?php if(!empty($newsDetail['news_articles']) && isset($newsDetail['news_articles'][0]['page_no'])): ?>
                    , Page No: <span style="color:blue;"><?php echo e($newsDetail['news_articles'][0]['page_no']); ?></span>
                <?php endif; ?>
                , Circulation Figure:<span> </span>, qAVE(Rs.):<span> </span> Date: <span style="color:blue;"><?php echo e($newsDetail['create_at']); ?></span>
            </p>
            <hr>
        </div>
    </div>
    <?php $__currentLoopData = $newsDetail['news_articles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $lightboxId = "img" . $index;
            $imageUrl = !empty($article['article_images']['artical_images_name']) ? asset('storage/uploads/' . $article['article_images']['artical_images_name']) : '';
        ?>
        <div class="row p-2">
            <div class="col-md-3">
                <?php if(!empty($article['article_images']['artical_images_name'])): ?>
                    <div class="download-icon text-right px-4">
                        <a href="<?php echo e($imageUrl); ?>" download>
                            <i class="fa fa-download text-primary" aria-hidden="true"></i>
                        </a>
                    </div>
                    <div class="thumbnail-wrapper">
                        <a href="#<?php echo e($lightboxId); ?>" aria-label="Click to enlarge image">
                            <img src="<?php echo e($imageUrl); ?>" class="thumbnail" alt="Thumbnail Image">
                        </a>
                    </div>
                    <div id="<?php echo e($lightboxId); ?>" class="lightbox">
                        <a href="#" class="close">&times;</a>
                        <img src="<?php echo e($imageUrl); ?>" alt="Popup Image">
                    </div>
                <?php endif; ?>
            </div>
            <div class="col-md-9 pt-1">
            <h6><?php echo e(strip_tags($article['news_artical'])); ?></h6>
            </div>
        </div>  
        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
        <div class="card" id="content-2" style="display:none;">
            <?php if(!empty($newsDetail)): ?>
                <div class="row p-2">
                    <div class="col-md-12 pt-1"> 
                        <h5 style="color:blue;"><a href="<?php echo e($newsDetail['website_url']); ?>"><?php echo e($newsDetail['head_line']); ?></a></h5>
                        <label for="">Summary</label> <br>
                        <p><?php echo e($newsDetail['summary']); ?></p>
                        <p>
                            Publication: <span style="color:blue;"><?php echo e($newsDetail['media_outlet']['MediaOutlet']); ?></span>, 
                            Journalist / Agency: <span style="color:blue;"><?php echo e($newsDetail['journalist']['Journalist'] ?? $newsDetail['agency']['Agency']); ?></span>, 
                            Edition: <span style="color:blue;"><?php echo e($newsDetail['edition']['Edition']); ?></span>, 
                            Supplement: <span style="color:blue;"><?php echo e($newsDetail['supplement']['Supplement']); ?></span>
                            <?php if(!empty($newsDetail['news_articles'])): ?>
                                , Page No: <span style="color:blue;"><?php echo e($newsDetail['news_articles'][0]['page_no']); ?></span>
                            <?php endif; ?>
                            , Circulation Figure:<span> </span>, qAVE(Rs.):<span> </span> Date: <span style="color:blue;"><?php echo e($newsDetail['create_at']); ?></span>
                        </p>
                        <hr>
                    </div>
                    <?php $__currentLoopData = $newsDetail['news_articles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $lightboxId = "img" . $index;
                        $imageUrl = !empty($article['artical_images_name']) ? asset('storage/uploads/' . $article['artical_images_name']) : '';
                    ?>
                        <div class="col-md-12 pt-1">
                            <h6><?php echo e($article['news_artical']); ?></h6>
                        </div>
                        <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
    <!-- Include html2pdf.js -->
<script>
        lightbox.option({
      'resizeDuration': 200,
      'wrapAround': true
    })
</script>
   
<script src="https://raw.githack.com/eKoopmans/html2pdf/master/dist/html2pdf.bundle.js"></script>
<script>
    document.getElementById('generatePDF').addEventListener('click', function() {
        var element = document.getElementById('content-2');
        var show_in_pdf = document.querySelectorAll('#show_in_pdf');

        element.style.display = 'block';
        // Hide header and footer and show PDF-specific content
        document.querySelectorAll('.no-pdf').forEach(function(el) {
            el.style.display = 'none';
        });
        show_in_pdf.forEach(function(el) {
            el.style.display = 'block';
        });

        var opt = {
            margin: [0, 0, 0, 0],
            filename: 'document.pdf',
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2 },
            jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' },
            pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
        };

        html2pdf().from(element).set(opt).save().then(function() {
            // Restore header and footer and hide PDF-specific content
            document.querySelectorAll('.no-pdf').forEach(function(el) {
                el.style.display = 'block';
            });
            element.style.display = 'none';
            show_in_pdf.forEach(function(el) {
                el.style.display = 'none';
            });
        });
    });
    </script>
    <?php echo $__env->make('common\footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\Trackify-Media\resources\views/news_article.blade.php ENDPATH**/ ?>