<link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.9/css/responsive.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/responsive/2.2.9/js/dataTables.responsive.min.js"></script>

<div class="row" id="getMediaData">
   
   <div class="col-md-12" >
       <div class="table-container-responsive">
        <table id="table" class="table table-bordered table-hover ">
            <thead>
                <tr>
                    <th>Sr. No</th>
                    <th>Publication Name</th>
                    <th>Edition</th>
                    <th>Supplement</th>
                    <th>Rate</th>
                    <th>New Rate</th>
                    <th>Circulation Figure</th>
                    <th>Status</th>
                    <th>Created On</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $i = 0; ?>
                    <?php $__currentLoopData = $addrate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $add_rate_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $i++; 
                    ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($add_rate_data -> publication); ?></td>
                    <td><?php echo e($add_rate_data -> edition); ?></td>
                    <td><?php echo e($add_rate_data -> supplement); ?></td>
                    <td><?php echo e($add_rate_data -> Rate); ?></td>
                    <td><?php echo e($add_rate_data -> NewRate); ?></td>
                    <td><?php echo e($add_rate_data -> Circulation_Fig); ?></td>
                    <td>  
                        <?php if($add_rate_data ->Status == 1): ?>
                            Inactive
                        <?php else: ?>
                            Active
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(\Carbon\Carbon::parse($add_rate_data->CreatedOn)->format('d/m/Y')); ?></td>  
                    <td>
                        <i class="fa fa-edit text-primary" onclick="editAddRate(<?php echo e(json_encode($add_rate_data)); ?>)"></i>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    
        </table>
       </div>
    </div>
</div>

<script>
       $('#table').DataTable();
</script><?php /**PATH C:\laravel\Trackify-Media\resources\views/master/addRate_ajax.blade.php ENDPATH**/ ?>