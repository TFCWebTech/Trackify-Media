 <?php echo $__env->make('common/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Begin Page Content -->
                <div class="container-fluid">
                <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->has('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                            <?php echo e($errors->first('error')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="p-1">
                        <div class="row">
                            <div class="col-md-6">
                                 <div class="card p-5">
                                    <div >
                                        <h1 class="h5 text-gray text-uppercase font-weight-bold">Update Information</h1>
                                    </div>
                                    <hr>
                                    <form action="<?php echo e(route('reporter.updateReporterInformation')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="user_id" value="<?php echo e($user->user_id); ?>">
                                <div class="form-group">
                                    <label for="user_name" class="font-weight-bold">Name</label>
                                    <input type="text" name="user_name" class="form-control" placeholder="Enter User Name" value="<?php echo e($user->user_name); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="user_email" class="font-weight-bold">Email</label>
                                    <input type="email" name="user_email" class="form-control" placeholder="Enter User Email" value="<?php echo e($user->user_email); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label for="user_status" class="font-weight-bold">Status</label>
                                    <select name="user_status" class="form-control" required>
                                        <option value="1" <?php echo e($user->user_status == 1 ? 'selected' : ''); ?>>Active</option>
                                        <option value="0" <?php echo e($user->user_status == 0 ? 'selected' : ''); ?>>Inactive</option>
                                    </select>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary">UPDATE</button>
                                </div>
                            </form>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="card p-5">
                                    <div>
                                        <h1 class="h5 text-gray text-uppercase font-weight-bold">Update Password</h1>
                                    </div>
                                    <hr>
                                    <form action ="<?php echo e(route('reporter.updateReporterPassword')); ?>" Method="POST" >
                                        <?php echo csrf_field(); ?>
                                            <input type="text" name="adminId" class="form-control "
                                                placeholder="Enter User Id" value="<?php echo e($user->user_id); ?>" hidden>
                                        <div class="form-group">
                                        <label for="" class="font-weight-bold"> Password</label>
                                            <input type="password" name="password" class="form-control "
                                                placeholder="Enter Password " >
                                        </div>
                                        <div class="form-group">
                                            <label for="" class="font-weight-bold">Confirm Password</label>
                                            <input type="password" name="password_confirmation" class="form-control "
                                                placeholder="Enter Confirm Password" >
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" class="btn btn-primary ">
                                                UPDATE
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->
    <?php echo $__env->make('common/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php /**PATH C:\laravel\Trackify-Media\resources\views/reporter_profile.blade.php ENDPATH**/ ?>