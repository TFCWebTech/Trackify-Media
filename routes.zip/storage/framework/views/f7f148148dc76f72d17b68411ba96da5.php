<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .table-wrapper {
            overflow-x: auto;
        }
        table {
            border-collapse: collapse;
            width: 100%;
        }
        td {
            padding: 5px;
            width: 33%;
        }
        th {
            text-align: center;
            padding: 5px;
        }
        .table-wrapper > table,
        .table-wrapper > table td,
        .table-wrapper > table th {
            border: 2px solid #ffffff;
        }
        .header_content {
            display: flex;
            justify-content: space-between;
        }
        @media (max-width: 725px) {
            .header_content {
                display: block;
                text-align: center;
            }
        }
        .body-content {
            padding: 0px 6px 0px 6px;
        }
        .footer {
            background-color: #6D6B6B;
            color: #ffffff;
            padding: 10px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card" style="background-color: #F9F9F9;">
            <div class="header" style="background-color: <?php echo e($get_client_details[0]['header_background_color']); ?>; padding:5px 10px;">
                <table width="100%" cellpadding="0" cellspacing="0">
                    <tr>
                        <td align="left">
                            <?php if($get_client_details[0]['logo_position'] === 'Left'): ?>
                                <img src="<?php echo e($get_client_details[0]['header_logo_url']); ?>" alt="logo" style="width:100px;"> <br>
                            <?php endif; ?>
                            <?php if($get_client_details[0]['trackify_link_status'] == 1): ?>
                                <a href="<?php echo e($get_client_details[0]['trackify_link']); ?>" style="font-size:12px; color:#ffffff;">powered by trackify media</a>
                            <?php endif; ?>
                        </td>
                        <td align="center">
                            <?php if($get_client_details[0]['logo_position'] === 'Center'): ?>
                                <img src="<?php echo e($get_client_details[0]['header_logo_url']); ?>" alt="logo" style="width:100px;"> <br>
                            <?php endif; ?>
                            <h5>
                                <a style="font-size:<?php echo e($get_client_details[0]['header_title_font_size']); ?>px; color:<?php echo e($get_client_details[0]['header_title_font_color']); ?>;">
                                    <?php echo e($get_client_details[0]['header_title_name']); ?>

                                </a><br>
                                <span style="display:block; font-size: 12px;"><?php echo e(date('l, M d, Y')); ?></span>
                            </h5>
                        </td>
                        <td align="right">
                            <?php if($get_client_details[0]['logo_position'] === 'Right'): ?>
                                <img src="<?php echo e($get_client_details[0]['header_logo_url']); ?>" alt="logo" style="width:100px;"> <br>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="col-md-12 mt-3 table-wrapper">
                <table>
                    <tr style="background-color: #6D6B6B; color: #ffffff;">
                        <th></th>
                        <th>Access Other Services</th>
                    </tr>
                    <?php if(!empty($get_client_details[0]['get_quick_links'])): ?>
                        <?php $__currentLoopData = $get_client_details[0]['get_quick_links']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($detail['quick_links_position'] == '1'): ?>
                                <tr style="background-color: #DCD5D5; color: #ffffff;">
                                    <td><p><?php echo e($detail['quick_links_name']); ?> (<?php echo e(count($get_client_details[0]['client_news'])); ?>)</p></td>
                                    <td><a href="#">Login</a></td>
                                </tr>
                            <?php elseif($detail['quick_links_position'] == '2'): ?>
                                <tr style="background-color: #DCD5D5; color: #ffffff;">
                                    <td><?php echo e($detail['quick_links_name']); ?> (<?php echo e(count($get_client_details[0]['compititors_data'])); ?>)</td>
                                    <td></td>
                                </tr>
                            <?php elseif($detail['quick_links_position'] == '3'): ?>
                                <tr style="background-color: #DCD5D5; color: #ffffff;">
                                    <td><?php echo e($detail['quick_links_name']); ?> (<?php echo e(count($get_client_details[0]['industry_data'])); ?>)</td>
                                    <td></td>
                                </tr>
                            <?php elseif($detail['quick_links_position'] == '4'): ?>
                                <tr style="background-color: #DCD5D5; color: #ffffff;">
                                    <td><?php echo e($detail['quick_links_name']); ?> (<?php echo e(count($get_client_details[0]['compititors_data'])); ?>)</td>
                                    <td></td>
                                </tr>
                            <?php elseif($detail['quick_links_position'] == '5'): ?>
                                <tr style="background-color: #DCD5D5; color: #ffffff;">
                                    <td><?php echo e($detail['quick_links_name']); ?> (<?php echo e(count($get_client_details[0]['industry_data'])); ?>)</td>
                                    <td></td>
                                </tr>
                            <?php elseif($detail['quick_links_position'] == '6'): ?>
                                <tr style="background-color: #DCD5D5; color: #ffffff;">
                                    <td><?php echo e($detail['quick_links_name']); ?> (<?php echo e(count($get_client_details[0]['compititors_data'])); ?>)</td>
                                    <td></td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr style="background-color: #DCD5D5; color: #ffffff;">
                        <td></td>
                        <td><a href="mailto:customerservice@trackify.info">customerservice@trackify.info</a></td>
                    </tr>
                </table>
            </div>

            <div class="body-content">
                <h4 style="background-color: #6D6B6B; color: #ffffff; padding:4px;"><?php echo e($details['client_name']); ?></h4>
                <?php $__currentLoopData = $get_client_details[0]['client_news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5>
                        <a href="<?php echo e($news['website_url']); ?>" style="color: <?php echo e($get_client_details[0]['content_headline_color']); ?>; font-size: <?php echo e($get_client_details[0]['content_headline_font_size']); ?>px; font-family: <?php echo e($get_client_details[0]['content_headline_font']); ?>;">
                            <?php echo e($news['head_line']); ?>

                        </a>
                    </h5>
                    <h6>Summary:</h6>
                    <p style="color: <?php echo e($get_client_details[0]['content_news_summary_color']); ?>; font-size: <?php echo e($get_client_details[0]['content_news_summary_font_size']); ?>px;">
                        <?php echo e($news['summary']); ?>

                    </p>
                    <p>
                        Date: <?php echo e(date('d-m-Y', strtotime($news['create_at']))); ?>,
                        Publication: <span style="color:blue;"><?php echo e($news['MediaOutlet']); ?></span>,
                        Journalist / Agency: <span style="color:blue;"><?php echo e($news['Journalist'] ?: $news['Agency']); ?></span>,
                        Edition: <span style="color:blue;"><?php echo e($news['Edition']); ?></span>,
                        Supplement: <span style="color:blue;"><?php echo e($news['Supplement']); ?></span>,
                        No of pages: <span style="color:blue;"><?php echo e($news['page_count']); ?></span>,
                        Circulation Figure: <span></span>, qAVE(Rs.): <span></span>
                    </p>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="body-content">
                <h4 style="background-color: #6D6B6B; color: #ffffff; padding:4px;">Competition</h4>
                <?php $__currentLoopData = $get_client_details[0]['compititors_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compititor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h4 style="background-color: #6D6B6B; color: #ffffff; padding:4px;"><?php echo e($compititor['Competitor_name']); ?></h4>
                        <?php $__currentLoopData = $compititor['news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5>
                                <a href="<?php echo e($news['website_url']); ?>" style="color: <?php echo e($get_client_details[0]['content_headline_color']); ?>; font-size: <?php echo e($get_client_details[0]['content_headline_font_size']); ?>px; font-family: <?php echo e($get_client_details[0]['content_headline_font']); ?>;">
                                    <?php echo e($news['head_line']); ?>

                                </a>
                            </h5>
                            <h6>Summary:</h6>
                            <p style="color: <?php echo e($get_client_details[0]['content_news_summary_color']); ?>; font-size: <?php echo e($get_client_details[0]['content_news_summary_font_size']); ?>px;">
                                <?php echo e($news['summary']); ?>

                            </p>
                            <p>
                                Date: <?php echo e(date('d-m-Y', strtotime($news['create_at']))); ?>,
                                Publication: <span style="color:blue;"><?php echo e($news['MediaOutlet']); ?></span>,
                                Journalist / Agency: <span style="color:blue;"><?php echo e($news['Journalist'] ?: $news['Agency']); ?></span>,
                                Edition: <span style="color:blue;"><?php echo e($news['Edition']); ?></span>,
                                Supplement: <span style="color:blue;"><?php echo e($news['Supplement']); ?></span>,
                                No of pages: <span style="color:blue;"><?php echo e($news['page_count']); ?></span>,
                                Circulation Figure: <span></span>, qAVE(Rs.): <span></span>
                            </p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="body-content">
                <h4 style="background-color: #6D6B6B; color: #ffffff; padding:4px;">Industry News</h4>
                <?php $__currentLoopData = $get_client_details[0]['industry_data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="body-content">
                        <h4 style="background-color: #6D6B6B; color: #ffffff; padding:4px;"><?php echo e($industry['industry_name']); ?></h4>
                        <?php $__currentLoopData = $industry['news']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5>
                                <a href="<?php echo e($news['website_url']); ?>" style="color: <?php echo e($get_client_details[0]['content_headline_color']); ?>; font-size: <?php echo e($get_client_details[0]['content_headline_font_size']); ?>px; font-family: <?php echo e($get_client_details[0]['content_headline_font']); ?>;">
                                    <?php echo e($news['head_line']); ?>

                                </a>
                            </h5>
                            <h6>Summary:</h6>
                            <p style="color: <?php echo e($get_client_details[0]['content_news_summary_color']); ?>; font-size: <?php echo e($get_client_details[0]['content_news_summary_font_size']); ?>px;">
                                <?php echo e($news['summary']); ?>

                            </p>
                            <p>
                                Date: <?php echo e(date('d-m-Y', strtotime($news['create_at']))); ?>,
                                Publication: <span style="color:blue;"><?php echo e($news['MediaOutlet']); ?></span>,
                                Journalist / Agency: <span style="color:blue;"><?php echo e($news['Journalist'] ?: $news['Agency']); ?></span>,
                                Edition: <span style="color:blue;"><?php echo e($news['Edition']); ?></span>,
                                Supplement: <span style="color:blue;"><?php echo e($news['Supplement']); ?></span>,
                                No of pages: <span style="color:blue;"><?php echo e($news['page_count']); ?></span>,
                                Circulation Figure: <span></span>, qAVE(Rs.): <span></span>
                            </p>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="footer">
                <p>
                    <span style="color:red;">This is an auto generated email – please do not reply to this email id </span>  
                    Thank you for reading. If you have any questions, please contact us at <a href="mailto:customerservice@trackify.info" style="color: #ffffff;">customerservice@trackify.info</a>.
                </p>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laravel\Trackify-Media\resources\views/emails/news_mail_with_template.blade.php ENDPATH**/ ?>