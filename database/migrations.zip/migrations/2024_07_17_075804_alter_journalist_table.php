<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('journalist', function (Blueprint $table) {
            // Drop the existing primary key
            $table->dropPrimary('gidJournalist');

            // Add a new auto-increment primary key column
            $table->bigIncrements('journalist_id')->unsigned()->primary()->first();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('journalist', function (Blueprint $table) {
            // Drop the auto-increment column added in the up method
            $table->dropColumn('journalist_id');

            // Restore the original primary key
            $table->string('gidJournalist', 45)->primary();
        });
    }
};
